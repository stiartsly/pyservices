import sys
import time

print "the very entry of relay"
time.sleep(100*60)

