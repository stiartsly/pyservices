import sys

from lib.errorCode import *
from lib.process   import *

pArray = []

def PopoboxMain(appName, params):
    print "[PopoCloud_Main] --> Entry."
    
    (retCode, child) = CreateProcess(appName, "bin/poposync", "600")
    if retCode.succeeded():
        pArray.append(child)

    return ESuccess

def PopoboxExit(appName, params):
    print "[PopoCloud_Exit] --> Entry."
    for child in pArray:
        KillProcess(child)

def PopoboxGetParams(appName, params):
    print "[PopoCloud_GetParams] --> Entry."

def PopoboxSetParams(appName, params):
    print "[PopoCloud_SetParams] --> Entry."


