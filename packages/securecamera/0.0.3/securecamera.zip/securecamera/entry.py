import sys

from lib.errorCode import *
from lib.process   import *

pArray = []

def PopoboxMain(appName, params):
    print "[PopoCloud_Main] --> Entry."
    
    (retCode, child) = CreateProcess(appName, "bin/securecamera1", "600")
    if retCode.succeeded():
        pArray.append(child)
    else:
        print "failed to start securecamera1 process."
        print "err:", retCode.dumps()

    (retCode, child) = CreateProcess(appName, "bin/securecamera2", "800")
    if retCode.succeeded():
        pArray.append(child)
        return ESuccess
    else :
        print "failed to start secureCamera2 process."
        print "err2:", retCode.dumps()
        child = pArray.pop()
        KillProcess(child)
        return EUndifinedError

    return ESuccess

def PopoboxExit(appName, params):
    print "[PopoCloud_Exit] --> Entry."
    for child in pArray:
        KillProcess(child)
        pArray.remove(child)

def PopoboxGetParams(appName, params):
    print "[PopoCloud_GetParams] --> Entry."

def PopoboxSetParams(appName, params):
    print "[PopoCloud_SetParams] --> Entry."


