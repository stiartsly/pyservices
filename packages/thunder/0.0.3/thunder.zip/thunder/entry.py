import sys

from lib.errorCode import *
from lib.process   import *

pArray = []

def _readFile(filePath):
    file = open(filePath)
    data = file.read()
    file.close()
    return data

def _makePath(appName, fileName):
    return "apps/" + appName + "/web/" + fileName

def PopoboxMain(appName, params):
    print "[PopoCloud_Main] --> Entry."
    
    (retCode, child) = CreateProcess(appName, "bin/thunder", "600")
    if retCode.succeeded():
        pArray.append(child)

    return ESuccess

def PopoboxExit(appName, params):
    print "[PopoCloud_Exit] --> Entry."
    for child in pArray:
        KillProcess(child)

def PopoboxGetParams(appName, params):
    print "[PopoCloud_GetParams] --> Entry.(params:%r)"%params
    return ESuccess
        
def PopoboxSetParams(appName, params):
    print "[PopoCloud_SetParams] --> Entry."


